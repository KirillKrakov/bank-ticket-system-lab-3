package com.example.applicationservice.model.enums;

public enum ApplicationStatus {
    DRAFT,
    SUBMITTED,
    IN_REVIEW,
    APPROVED,
    REJECTED
}
