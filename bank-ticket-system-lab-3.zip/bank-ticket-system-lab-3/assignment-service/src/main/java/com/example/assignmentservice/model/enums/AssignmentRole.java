package com.example.assignmentservice.model.enums;

public enum AssignmentRole {
    PRODUCT_OWNER,
    SUPPORT,
    RESELLER,
    VIEWER
}