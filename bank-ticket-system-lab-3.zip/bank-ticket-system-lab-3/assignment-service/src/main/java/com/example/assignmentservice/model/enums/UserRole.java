package com.example.assignmentservice.model.enums;

public enum UserRole {
    ROLE_CLIENT,
    ROLE_MANAGER,
    ROLE_ADMIN
}