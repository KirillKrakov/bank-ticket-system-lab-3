package com.example.productservice.model.enums;

public enum UserRole {
    ROLE_CLIENT,
    ROLE_MANAGER,
    ROLE_ADMIN
}