package com.example.userservice.model.enums;

public enum UserRole {
    ROLE_CLIENT,
    ROLE_MANAGER,
    ROLE_ADMIN
}